

Components of the Main page

        Top Headlines
            Straight Top 20 Headline pull from api
        Selected Sources
            pull api based on select/filter source
            Each item returned will have the abilty to subscribe
                when subscribed button will be displayed as orange
        Personal Feed
            Display all subscribed articles
            Link to actual article

